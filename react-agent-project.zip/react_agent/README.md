# ReAct Agent

A from-scratch implementation of the **ReAct (Reason + Act)** agentic pattern in Python.  
Uses OpenAI for reasoning and DuckDuckGo's free Instant Answer API for live web search.  
No LangChain, LlamaIndex, CrewAI, or AutoGen — just pure Python.

---

## How It Works

The agent follows this loop for every question:

```
Question
   └─► Thought  (LLM reasons about what to do)
          └─► Action: Search["query"]
                 └─► Observation  (live web search result)
                        └─► Thought  (LLM reasons with new info)
                               └─► … (repeat as needed)
                                      └─► Final Answer
```

If the LLM already knows the answer it skips the search and responds with
`Final Answer:` immediately.

---

## Project Structure

```
react_agent/
├── agent.py          # ReAct loop — orchestrates Thought / Action / Observation
├── search.py         # Web search via DuckDuckGo Instant Answer API
├── llm.py            # Thin OpenAI Chat Completions wrapper + system prompt
├── main.py           # Entry point: examples + interactive mode
├── requirements.txt  # Python dependencies
└── README.md
```

---

## Setup

### 1. Install dependencies

```bash
cd react_agent
pip install -r requirements.txt
```

### 2. Run

```bash
python main.py
```

You will be prompted for your OpenAI API key.  
**The key is never stored anywhere** — it lives only in memory for the session.

You can also pass it as a CLI argument (useful for scripting):

```bash
python main.py sk-your-key-here
```

---

## Configuration

Edit the `ReActAgent(...)` call in `main.py` to change:

| Parameter        | Default        | Description                          |
|------------------|----------------|--------------------------------------|
| `model`          | `gpt-4o-mini`  | OpenAI model — swap to `gpt-4o` for higher quality |
| `max_iterations` | `6`            | Safety cap on search rounds          |
| `verbose`        | `True`         | Print each ReAct step to stdout      |

---

## Search API limitations

The DuckDuckGo Instant Answer API is **free and requires no key**, but:

- Best for factual / encyclopedic queries (famous people, capitals, science terms).
- May return empty results for very recent news or niche topics.
- Does not scrape full web pages — only returns pre-indexed abstracts.

For production use, consider [SerpAPI](https://serpapi.com/) or [Brave Search API](https://brave.com/search/api/).

---

## Sample Output

### Example 1 — web search required

```
============================================================
Question: Who is the current CEO of Microsoft?
============================================================

[Iteration 1]
Thought: I need recent information to answer this accurately.
Action: Search[current CEO of Microsoft]

🔍 Searching: "current CEO of Microsoft"
📋 Observation:
Answer: Satya Nadella is Chairman and CEO of Microsoft.
Source: https://en.wikipedia.org/wiki/Satya_Nadella

[Iteration 2]
Thought: The search confirms Satya Nadella is the CEO.
Final Answer: The current CEO of Microsoft is Satya Nadella.

============================================================
✅ Final Answer: The current CEO of Microsoft is Satya Nadella.
============================================================
```

### Example 2 — no search needed

```
============================================================
Question: What is the capital of Japan?
============================================================

[Iteration 1]
Thought: I already know this — Tokyo is the capital of Japan.
Final Answer: The capital of Japan is Tokyo.

============================================================
✅ Final Answer: The capital of Japan is Tokyo.
============================================================
```

---

## Customising

### Add your own tools

Extend the `_execute_search` method in `agent.py` to dispatch to different
tools based on the action type (e.g. `Action: Calculate[...]`, `Action: LookupDB[...]`).

### Use a different search backend

Replace the `WebSearcher` class in `search.py` with any HTTP-based search API.
The only contract is that `search(query: str) -> SearchResult` is satisfied.
