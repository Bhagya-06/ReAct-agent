"""
run_agent.py — Streaming bridge for the ReAct agent.

Reads a JSON payload from stdin:
  {"question": "...", "api_key": "..."}

Outputs newline-delimited JSON to stdout, one line per step:
  {"type": "thought",       "content": "..."}
  {"type": "action",        "content": "...", "query": "..."}
  {"type": "observation",   "content": "..."}
  {"type": "final_answer",  "content": "..."}
  {"type": "error",         "content": "..."}

The Express SSE route reads these lines and forwards them to the browser.
Do NOT import this file — it is only meant to be run as a subprocess.
"""

import json
import re
import sys

# Reuse the existing modules without modifying them
from llm import LLMClient, SYSTEM_PROMPT
from search import WebSearcher

_ACTION_RE = re.compile(r"Action:\s*Search\[(.+?)\]", re.IGNORECASE)
_FINAL_RE = re.compile(r"Final Answer:\s*(.+)", re.IGNORECASE | re.DOTALL)
_THOUGHT_RE = re.compile(r"Thought:\s*(.+?)(?=\n(?:Action|Final Answer)|$)", re.IGNORECASE | re.DOTALL)


def emit(event_type: str, content: str, **extra) -> None:
    """Write a JSON-line event to stdout and flush immediately."""
    payload = {"type": event_type, "content": content.strip(), **extra}
    print(json.dumps(payload), flush=True)


def run(question: str, api_key: str, max_iterations: int = 6) -> None:
    llm = LLMClient(api_key=api_key)
    searcher = WebSearcher()

    messages: list[dict] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": f"Question: {question}"},
    ]

    for _ in range(max_iterations):
        try:
            reply = llm.complete(messages)
        except PermissionError as exc:
            emit("error", str(exc))
            return
        except RuntimeError as exc:
            emit("error", str(exc))
            return

        messages.append({"role": "assistant", "content": reply})

        # Parse thought
        thought_match = _THOUGHT_RE.search(reply)
        if thought_match:
            emit("thought", thought_match.group(1))

        # Check for final answer
        final_match = _FINAL_RE.search(reply)
        if final_match:
            emit("final_answer", final_match.group(1))
            return

        # Check for action (search)
        action_match = _ACTION_RE.search(reply)
        if action_match:
            query = action_match.group(1).strip()
            emit("action", f"Search: {query}", query=query)

            try:
                result = searcher.search(query)
                observation = result.to_observation()
            except (ConnectionError, ValueError) as exc:
                observation = f"Search failed: {exc}"

            emit("observation", observation)
            messages.append({"role": "user", "content": f"Observation: {observation}"})
            continue

        # No structured output — treat as final answer
        emit("final_answer", reply)
        return

    emit("error", f"Reached maximum iterations ({max_iterations}) without a final answer.")


def main() -> None:
    raw = sys.stdin.read().strip()
    if not raw:
        emit("error", "No input provided.")
        return

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as exc:
        emit("error", f"Invalid JSON input: {exc}")
        return

    question = payload.get("question", "").strip()
    api_key = payload.get("api_key", "").strip()

    if not question:
        emit("error", "Missing 'question' field.")
        return
    if not api_key:
        emit("error", "Missing 'api_key' field.")
        return

    run(question, api_key)


if __name__ == "__main__":
    main()
