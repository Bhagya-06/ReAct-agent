import { Router, type IRouter } from "express";
import { spawn } from "child_process";
import path from "path";

const router: IRouter = Router();

// Resolve the react_agent directory relative to workspace root.
// esbuild bundles to dist/, so we resolve from cwd (workspace root in prod,
// artifacts/api-server in dev) using the same pattern as server.md.
const workspaceRoot = process.cwd().endsWith(path.join("artifacts", "api-server"))
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const agentDir = path.resolve(workspaceRoot, "react_agent");

router.post("/agent/run", async (req, res): Promise<void> => {
  const { question, api_key } = req.body ?? {};

  if (!question || typeof question !== "string") {
    res.status(400).json({ error: "Missing or invalid 'question' field." });
    return;
  }
  if (!api_key || typeof api_key !== "string") {
    res.status(400).json({ error: "Missing or invalid 'api_key' field." });
    return;
  }

  // SSE headers — must be set before any writes
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const payload = JSON.stringify({ question, api_key });

  const child = spawn("python3", ["run_agent.py"], {
    cwd: agentDir,
    stdio: ["pipe", "pipe", "pipe"],
  });

  // Write the question + key to stdin then signal EOF
  child.stdin.on("error", () => { /* ignore EPIPE if child exits early */ });
  child.stdin.write(payload);
  child.stdin.end();

  let buffer = "";
  let clientGone = false;

  // Forward each JSON-line from Python stdout as an SSE data event
  child.stdout.on("data", (chunk: Buffer) => {
    buffer += chunk.toString();
    const lines = buffer.split("\n");
    buffer = lines.pop() ?? "";

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      if (!clientGone) res.write(`data: ${trimmed}\n\n`);
    }
  });

  child.stderr.on("data", (chunk: Buffer) => {
    req.log.error({ stderr: chunk.toString().trim() }, "agent stderr");
  });

  child.on("close", (code, signal) => {
    // Flush any remaining buffered output
    if (buffer.trim() && !clientGone) {
      res.write(`data: ${buffer.trim()}\n\n`);
    }

    // Only surface an error when Python itself exited non-zero
    // (signal = null means normal exit; code = null means killed by signal — that's
    //  our own SIGTERM cleanup when the client disconnects, so stay quiet)
    if (code !== null && code !== 0 && !clientGone) {
      const errEvent = JSON.stringify({
        type: "error",
        content: `Agent exited with code ${code}.`,
      });
      res.write(`data: ${errEvent}\n\n`);
    }

    if (!clientGone) {
      res.write(`data: ${JSON.stringify({ type: "done" })}\n\n`);
      res.end();
    }
  });

  child.on("error", (err) => {
    req.log.error({ err }, "Failed to spawn agent subprocess");
    if (!clientGone) {
      res.write(`data: ${JSON.stringify({ type: "error", content: `Failed to start agent: ${err.message}` })}\n\n`);
      res.end();
    }
  });

  // Use res.on("close") — this fires when the SSE *response* stream is terminated
  // by the client, which is the correct signal to clean up the child process.
  // req.on("close") fires as soon as the request body is consumed (too early for SSE).
  res.on("close", () => {
    clientGone = true;
    child.kill("SIGTERM");
  });
});

export default router;
