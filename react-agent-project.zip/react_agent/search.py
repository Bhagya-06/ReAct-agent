"""
search.py — Web search module using DuckDuckGo Instant Answer API.

Limitation note: DuckDuckGo's Instant Answer API is free but returns
summarized/abstract results rather than full web pages. It works well for
factual queries (famous people, capitals, definitions) but may return empty
results for very recent or niche topics. For production use, consider the
SerpAPI or Brave Search API.
"""

import requests
from typing import Optional


class SearchResult:
    """Structured container for a single search observation."""

    def __init__(self, query: str, answer: str, abstract: str, source: str):
        self.query = query
        self.answer = answer
        self.abstract = abstract
        self.source = source

    def to_observation(self) -> str:
        """Format the result as a readable observation string for the agent."""
        parts: list[str] = []

        if self.answer:
            parts.append(f"Answer: {self.answer}")
        if self.abstract:
            parts.append(f"Summary: {self.abstract}")
        if self.source:
            parts.append(f"Source: {self.source}")

        if not parts:
            return "No relevant results found for this query."

        return "\n".join(parts)


class WebSearcher:
    """
    Performs live web searches using the DuckDuckGo Instant Answer API.
    No API key required.
    """

    DDGO_URL = "https://api.duckduckgo.com/"

    def __init__(self, timeout: int = 10):
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "ReActAgent/1.0 (educational project)"
        })

    def search(self, query: str) -> SearchResult:
        """
        Search the web for a query and return a structured SearchResult.

        Args:
            query: The search query string.

        Returns:
            A SearchResult with the best available information.

        Raises:
            ConnectionError: If the network request fails.
            ValueError: If the API returns an unparseable response.
        """
        try:
            response = self.session.get(
                self.DDGO_URL,
                params={
                    "q": query,
                    "format": "json",
                    "no_html": "1",
                    "skip_disambig": "1",
                },
                timeout=self.timeout,
            )
            response.raise_for_status()
        except requests.exceptions.Timeout:
            raise ConnectionError(
                f"Search timed out after {self.timeout}s for query: '{query}'"
            )
        except requests.exceptions.ConnectionError as exc:
            raise ConnectionError(
                f"Network error while searching for '{query}': {exc}"
            )
        except requests.exceptions.HTTPError as exc:
            raise ConnectionError(
                f"Search API returned error {response.status_code}: {exc}"
            )

        try:
            data = response.json()
        except ValueError as exc:
            raise ValueError(f"Could not parse search API response: {exc}")

        # DuckDuckGo returns the best instant answer in "Answer",
        # and a longer Wikipedia-style abstract in "Abstract".
        answer: str = data.get("Answer", "").strip()
        abstract: str = data.get("Abstract", "").strip()
        source: str = data.get("AbstractURL", "").strip() or data.get(
            "AnswerURL", ""
        ).strip()

        # Fallback: try related topics if both main fields are empty
        if not answer and not abstract:
            related: list[dict] = data.get("RelatedTopics", [])
            texts: list[str] = []
            for topic in related[:3]:
                if isinstance(topic, dict) and topic.get("Text"):
                    texts.append(topic["Text"])
            abstract = " | ".join(texts)

        return SearchResult(
            query=query,
            answer=answer,
            abstract=abstract,
            source=source,
        )
