"""
agent.py — The ReAct agent core.

Implements the Reason + Act loop:

  Question
    └─► Thought ──► Action: Search[query]
                       └─► Observation (from searcher)
                              └─► Thought ──► ... ──► Final Answer

The loop continues until either:
  • The model produces a "Final Answer:" line, or
  • The maximum number of iterations is reached.
"""

import re
from llm import LLMClient, SYSTEM_PROMPT
from search import WebSearcher


# Regex patterns for parsing model output
_ACTION_RE = re.compile(r"Action:\s*Search\[(.+?)\]", re.IGNORECASE)
_FINAL_RE = re.compile(r"Final Answer:\s*(.+)", re.IGNORECASE | re.DOTALL)


class ReActAgent:
    """
    A ReAct agent that answers questions by interleaving reasoning with
    live web searches.

    Usage:
        agent = ReActAgent(api_key="sk-...")
        answer = agent.run("Who is the current CEO of Microsoft?")
        print(answer)
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        max_iterations: int = 6,
        verbose: bool = True,
    ):
        """
        Args:
            api_key:        OpenAI API key supplied at runtime.
            model:          OpenAI model to use.
            max_iterations: Safety cap — stop after this many Thought/Action cycles.
            verbose:        Print each step of the ReAct loop to stdout.
        """
        self.verbose = verbose
        self.max_iterations = max_iterations
        self._llm = LLMClient(api_key=api_key, model=model)
        self._searcher = WebSearcher()

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def run(self, question: str) -> str:
        """
        Run the ReAct loop for a single question.

        Args:
            question: The user's question as a plain string.

        Returns:
            The final answer produced by the agent.
        """
        self._print_header(question)

        # The conversation history starts with the system prompt and
        # the user's question. We grow it with each Thought/Observation
        # so the model always has the full context.
        messages: list[dict] = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Question: {question}"},
        ]

        for iteration in range(1, self.max_iterations + 1):
            # ── Step 1: Ask the LLM for its next Thought (+ optional Action) ──
            assistant_reply = self._llm.complete(messages)
            messages.append({"role": "assistant", "content": assistant_reply})

            self._log(f"[Iteration {iteration}]")
            self._log(assistant_reply)

            # ── Step 2: Check for a Final Answer ──────────────────────────────
            final_match = _FINAL_RE.search(assistant_reply)
            if final_match:
                answer = final_match.group(1).strip()
                self._print_footer(answer)
                return answer

            # ── Step 3: Check for an Action (web search) ──────────────────────
            action_match = _ACTION_RE.search(assistant_reply)
            if action_match:
                query = action_match.group(1).strip()
                self._log(f"\n🔍 Searching: \"{query}\"")
                observation = self._execute_search(query)
                self._log(f"📋 Observation:\n{observation}\n")

                # Inject the observation as a user turn so the model can
                # continue reasoning with the new evidence.
                messages.append({
                    "role": "user",
                    "content": f"Observation: {observation}",
                })
                continue

            # ── Step 4: No Action and no Final Answer ─────────────────────────
            # The model produced a freeform reply — treat it as a final answer
            # rather than looping endlessly.
            self._log(
                "\n⚠️  No Action or Final Answer detected. "
                "Using the last reply as the answer.\n"
            )
            self._print_footer(assistant_reply)
            return assistant_reply

        # Safety: max iterations reached without a Final Answer
        timeout_msg = (
            f"Maximum iterations ({self.max_iterations}) reached "
            "without a definitive answer. Here is what I found:\n\n"
            + (messages[-1]["content"] if messages else "No information gathered.")
        )
        self._print_footer(timeout_msg)
        return timeout_msg

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _execute_search(self, query: str) -> str:
        """Run a web search and return an observation string."""
        try:
            result = self._searcher.search(query)
            return result.to_observation()
        except ConnectionError as exc:
            return f"Search failed (network error): {exc}"
        except ValueError as exc:
            return f"Search failed (parse error): {exc}"

    def _log(self, text: str) -> None:
        if self.verbose:
            print(text)

    def _print_header(self, question: str) -> None:
        if self.verbose:
            sep = "=" * 60
            print(f"\n{sep}")
            print(f"Question: {question}")
            print(sep)

    def _print_footer(self, answer: str) -> None:
        if self.verbose:
            sep = "=" * 60
            print(f"\n{sep}")
            print(f"✅ Final Answer: {answer}")
            print(sep + "\n")
