import React, { useState, useEffect, useRef } from "react";
import { Play, Square, Loader2, KeyRound, Terminal, CheckCircle2, Search, ArrowRight, BrainCircuit, XCircle, AlertCircle, RefreshCcw, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useTheme } from "@/components/theme-provider";

type StepType = 'thought' | 'action' | 'observation' | 'final_answer' | 'error' | 'done';

interface AgentStep {
  id: string;
  type: StepType;
  content: string;
  query?: string;
}

const StepIcon = ({ type }: { type: StepType }) => {
  switch (type) {
    case 'thought': return <BrainCircuit className="w-4 h-4 text-muted-foreground" />;
    case 'action': return <Search className="w-4 h-4 text-blue-500" />;
    case 'observation': return <Terminal className="w-4 h-4 text-emerald-500" />;
    case 'final_answer': return <CheckCircle2 className="w-5 h-5 text-indigo-500" />;
    case 'error': return <XCircle className="w-5 h-5 text-destructive" />;
    default: return <ArrowRight className="w-4 h-4" />;
  }
};

export default function Home() {
  const [apiKey, setApiKey] = useState("");
  const [question, setQuestion] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [error, setError] = useState<string | null>(null);
  
  const { toast } = useToast();
  const { theme, setTheme } = useTheme();
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    const savedKey = localStorage.getItem("react-agent-api-key");
    if (savedKey) setApiKey(savedKey);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [steps]);

  const handleRun = async () => {
    if (!apiKey) {
      toast({ title: "API Key required", description: "Please enter your OpenAI API key", variant: "destructive" });
      return;
    }
    if (!question) {
      toast({ title: "Question required", description: "Please enter a question to ask", variant: "destructive" });
      return;
    }

    localStorage.setItem("react-agent-api-key", apiKey);
    setSteps([]);
    setError(null);
    setIsRunning(true);
    
    abortControllerRef.current = new AbortController();

    try {
      const response = await fetch('/api/agent/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, api_key: apiKey }),
        signal: abortControllerRef.current.signal
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const json = line.slice(6).trim();
            if (json) {
              try {
                const event = JSON.parse(json);
                setSteps(prev => [...prev, {
                  id: Math.random().toString(36).substring(7),
                  type: event.type,
                  content: event.content,
                  query: event.query
                }]);
              } catch (e) {
                console.error("Failed to parse event:", json);
              }
            }
          }
        }
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setError(err.message || "An error occurred");
        setSteps(prev => [...prev, {
          id: Math.random().toString(36).substring(7),
          type: 'error',
          content: err.message || "An error occurred while communicating with the agent."
        }]);
      }
    } finally {
      setIsRunning(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
      setIsRunning(false);
      setSteps(prev => [...prev, {
        id: Math.random().toString(36).substring(7),
        type: 'error',
        content: 'Execution stopped by user.'
      }]);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans">
      <header className="border-b bg-card/50 backdrop-blur sticky top-0 z-10">
        <div className="container mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono font-semibold tracking-tight text-lg">
            <BrainCircuit className="w-5 h-5 text-primary" />
            <span>ReAct_Agent</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5 mr-4 px-2 py-1 rounded bg-muted/50 font-mono text-xs">
              <KeyRound className="w-3.5 h-3.5" />
              <span>{apiKey ? 'API: OK' : 'API: MISSING'}</span>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
              {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8 max-w-4xl grid gap-8">
        
        {/* Setup Section */}
        <Card className="shadow-sm border-border/50">
          <CardHeader>
            <CardTitle>Initialize Agent</CardTitle>
            <CardDescription>Provide your API key and task to start the reasoning loop.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-6">
            <div className="grid gap-2">
              <Label htmlFor="apiKey" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">OpenAI API Key</Label>
              <Input 
                id="apiKey"
                type="password" 
                placeholder="sk-..." 
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="font-mono bg-muted/30"
                disabled={isRunning}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="question" className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Task / Question</Label>
              <Textarea 
                id="question"
                placeholder="What would you like the agent to figure out?" 
                className="min-h-[100px] resize-y bg-muted/30"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                disabled={isRunning}
              />
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-2 border-t bg-muted/10 px-6 py-4">
            {isRunning ? (
              <Button variant="destructive" onClick={handleStop} className="w-32">
                <Square className="w-4 h-4 mr-2" /> Stop
              </Button>
            ) : (
              <Button onClick={handleRun} disabled={!question || !apiKey} className="w-32">
                <Play className="w-4 h-4 mr-2" /> Run Agent
              </Button>
            )}
          </CardFooter>
        </Card>

        {/* Execution Output Section */}
        {(steps.length > 0 || isRunning) && (
          <Card className="shadow-sm border-border/50 flex flex-col overflow-hidden">
            <CardHeader className="border-b bg-muted/10 py-3 px-4 flex flex-row items-center justify-between sticky top-0">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-muted-foreground" />
                <CardTitle className="text-sm font-mono tracking-tight">Execution Trace</CardTitle>
              </div>
              {isRunning && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground font-mono">
                  <Loader2 className="w-3 h-3 animate-spin" />
                  Processing...
                </div>
              )}
            </CardHeader>
            <div 
              ref={scrollRef}
              className="p-4 flex flex-col gap-4 overflow-y-auto max-h-[600px] font-mono text-sm bg-zinc-950 text-zinc-300 dark:bg-zinc-950/50"
            >
              {steps.map((step, index) => {
                if (step.type === 'done') {
                  return (
                    <div key={step.id} className="flex items-center gap-2 text-muted-foreground py-2 border-t border-zinc-800 mt-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Process completed successfully.</span>
                    </div>
                  );
                }

                return (
                  <div 
                    key={step.id} 
                    className={`flex flex-col gap-1 p-3 rounded-md border ${
                      step.type === 'thought' ? 'bg-zinc-900 border-zinc-800' :
                      step.type === 'action' ? 'bg-blue-950/20 border-blue-900/50 text-blue-100' :
                      step.type === 'observation' ? 'bg-emerald-950/20 border-emerald-900/50 text-emerald-100' :
                      step.type === 'final_answer' ? 'bg-indigo-950/30 border-indigo-500/30 text-indigo-50' :
                      step.type === 'error' ? 'bg-red-950/20 border-red-900/50 text-red-100' :
                      'bg-zinc-900 border-zinc-800'
                    } animate-in fade-in slide-in-from-bottom-2 duration-300`}
                  >
                    <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider opacity-70 mb-1">
                      <StepIcon type={step.type} />
                      <span>{step.type.replace('_', ' ')}</span>
                      {step.query && (
                        <span className="ml-auto opacity-50 lowercase tracking-normal">
                          query: "{step.query}"
                        </span>
                      )}
                    </div>
                    <div className="whitespace-pre-wrap break-words">
                      {step.content}
                    </div>
                  </div>
                )
              })}
              
              {isRunning && steps.length > 0 && steps[steps.length - 1].type !== 'done' && (
                <div className="flex gap-2 items-center text-zinc-500 p-2 animate-pulse">
                  <div className="w-1.5 h-1.5 rounded-full bg-current" />
                  <div className="w-1.5 h-1.5 rounded-full bg-current animation-delay-150" />
                  <div className="w-1.5 h-1.5 rounded-full bg-current animation-delay-300" />
                </div>
              )}
            </div>
          </Card>
        )}
      </main>
    </div>
  );
}
