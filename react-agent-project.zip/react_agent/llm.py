"""
llm.py — Thin wrapper around the OpenAI Chat Completions API.

Keeps all model interaction in one place so agent.py stays focused on
the ReAct loop logic.
"""

from openai import OpenAI, AuthenticationError, RateLimitError, APIConnectionError
from typing import Optional


# System prompt that teaches the model the exact ReAct format.
# The agent loop parses "Action:" lines to decide when to search.
SYSTEM_PROMPT = """You are a ReAct (Reason + Act) agent. You answer questions
by interleaving Thought, Action, and Observation steps before producing a
Final Answer.

Always follow this exact format (use the exact labels):

Thought: <your reasoning about what to do next>
Action: Search[<search query>]

OR, if you already know the answer or have enough information:

Thought: <your reasoning>
Final Answer: <your complete answer>

Rules:
- After each Action the user will provide an Observation.
- Use the Observation to decide your next Thought or Final Answer.
- Only call one Action per response.
- Do NOT fabricate Observations — wait for them to be provided.
- When you have enough information, stop searching and give a Final Answer.
- Keep Thoughts concise (1–3 sentences).
- If a search returns no useful results, try a different query or answer
  from your own knowledge.
"""


class LLMClient:
    """Wraps the OpenAI API for single-turn chat completions."""

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        temperature: float = 0.0,
        max_tokens: int = 512,
    ):
        """
        Args:
            api_key:     Your OpenAI API key (passed at runtime, never hardcoded).
            model:       OpenAI model to use. Defaults to gpt-4o-mini for speed/cost.
            temperature: 0.0 for deterministic, reproducible reasoning.
            max_tokens:  Maximum tokens per completion.
        """
        if not api_key or not api_key.strip():
            raise ValueError("api_key must be a non-empty string.")

        self.model = model
        self.temperature = temperature
        self.max_tokens = max_tokens
        self._client = OpenAI(api_key=api_key.strip())

    def complete(self, messages: list[dict]) -> str:
        """
        Send a list of chat messages and return the assistant's reply text.

        Args:
            messages: List of {"role": ..., "content": ...} dicts.

        Returns:
            The assistant message text.

        Raises:
            PermissionError: If the API key is invalid.
            RuntimeError:    On rate-limit, connection, or unexpected errors.
        """
        try:
            response = self._client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
            )
        except AuthenticationError:
            raise PermissionError(
                "OpenAI rejected the API key. "
                "Please check that you entered it correctly."
            )
        except RateLimitError:
            raise RuntimeError(
                "OpenAI rate limit exceeded. "
                "Wait a moment and try again, or check your usage limits."
            )
        except APIConnectionError as exc:
            raise RuntimeError(
                f"Could not connect to OpenAI API: {exc}"
            )

        content: Optional[str] = response.choices[0].message.content
        if not content:
            raise RuntimeError(
                "OpenAI returned an empty response. "
                "Try rephrasing the question."
            )
        return content.strip()
