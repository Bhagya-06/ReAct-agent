"""
main.py — Entry point for the ReAct agent.

Run:
    cd react_agent
    python main.py

The script will prompt you for your OpenAI API key (never stored anywhere),
then run three example questions to demonstrate the full ReAct loop.
You can also drop into interactive mode to ask your own questions.
"""

import sys
from agent import ReActAgent


# ── Example questions that show different agent behaviors ─────────────────────

EXAMPLES: list[str] = [
    "Who is the current CEO of Microsoft?",
    "What is the capital of Japan?",
    "What is the latest version of Python?",
]


def get_api_key() -> str:
    """
    Prompt the user for their OpenAI API key at runtime.
    The key is never written to disk or hardcoded anywhere.
    """
    print("=" * 60)
    print("  ReAct Agent — Reason + Act with live web search")
    print("=" * 60)
    print()
    print("Your OpenAI API key is required to call the language model.")
    print("It will only be used for this session and never stored.\n")

    # Allow passing the key as a CLI argument for scripting:
    #   python main.py sk-...
    if len(sys.argv) > 1:
        key = sys.argv[1].strip()
        print("(Using API key from command-line argument)\n")
        return key

    key = input("Enter your OpenAI API Key: ").strip()
    if not key:
        print("Error: API key cannot be empty.")
        sys.exit(1)
    return key


def run_examples(agent: ReActAgent) -> None:
    """Run the built-in example questions."""
    print("\n" + "─" * 60)
    print("  Running example questions…")
    print("─" * 60)

    for question in EXAMPLES:
        try:
            agent.run(question)
        except PermissionError as exc:
            print(f"\n❌ Authentication error: {exc}")
            sys.exit(1)
        except RuntimeError as exc:
            print(f"\n⚠️  Runtime error: {exc}")


def interactive_mode(agent: ReActAgent) -> None:
    """Let the user ask their own questions in a loop."""
    print("\n" + "─" * 60)
    print("  Interactive mode  (type 'exit' or 'quit' to stop)")
    print("─" * 60)

    while True:
        try:
            question = input("\nYour question: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not question:
            continue
        if question.lower() in {"exit", "quit", "q"}:
            print("Goodbye!")
            break

        try:
            agent.run(question)
        except PermissionError as exc:
            print(f"\n❌ Authentication error: {exc}")
            break
        except RuntimeError as exc:
            print(f"\n⚠️  Error: {exc}")


def main() -> None:
    api_key = get_api_key()

    # Instantiate the agent — API key is passed explicitly, never hardcoded.
    agent = ReActAgent(
        api_key=api_key,
        model="gpt-4o-mini",   # fast and cheap; swap for "gpt-4o" for higher quality
        max_iterations=6,
        verbose=True,
    )

    # 1. Run the built-in examples
    run_examples(agent)

    # 2. Drop into interactive mode
    interactive_mode(agent)


if __name__ == "__main__":
    main()
